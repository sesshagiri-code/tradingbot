import React, { useEffect, useState } from "react";
import { api } from "./api.js";
import Market from "./pages/Market.jsx";
import Backtest from "./pages/Backtest.jsx";
import Paper from "./pages/Paper.jsx";
import BestStocks from "./pages/BestStocks.jsx";
import Options from "./pages/Options.jsx";
import RLPaper from "./pages/RLPaper.jsx";

const TABS = {
  Market,
  Backtest,
  "Paper Trading": Paper,
  "Best Stocks": BestStocks,
  Options,
  "Daily Paper": RLPaper,
};

export default function App() {
  const [tab, setTab] = useState("Backtest");
  const [executionMode, setExecutionMode] = useState("paper");
  const [auth, setAuth] = useState({ configured: false, authenticated: false });
  const [liveStatus, setLiveStatus] = useState({ enabled: false, max_order_value: 0 });
  const [instruments, setInstruments] = useState({});
  const [instrumentError, setInstrumentError] = useState("");

  useEffect(() => {
    api("/auth/status").then(setAuth).catch(() => {});
    api("/live/status").then(setLiveStatus).catch(() => {});
    api("/instruments").then(setInstruments).catch((e) => setInstrumentError(e.message));
  }, []);

  const refreshInstruments = async () => {
    try {
      setInstruments(await api("/instruments?refresh=true"));
      setInstrumentError("");
    } catch (e) {
      setInstrumentError(e.message);
    }
  };

  const login = async () => {
    try {
      const { url } = await api("/auth/login");
      window.location.href = url;
    } catch (e) {
      alert(e.message + "\nSet UPSTOX_API_KEY/SECRET in backend/.env");
    }
  };

  const Page = TABS[tab];
  return (
    <>
      <header>
        <h1>AI Trading Lab · Upstox</h1>
        <div>
          <span className="badge">{auth.authenticated ? "Upstox connected" : "Demo data (not connected)"}</span>{" "}
          <button
            className={executionMode === "live" ? "primary sell" : "primary"}
            aria-pressed={executionMode === "live"}
            disabled={executionMode === "paper" && !liveStatus.enabled}
            title={liveStatus.enabled ? "Switch between Paper and Live order mode" : "Live trading is disabled on the backend"}
            onClick={() => setExecutionMode((mode) => (mode === "paper" ? "live" : "paper"))}
          >
            {executionMode === "live" ? "Mode: LIVE" : "Mode: PAPER"}
            {!liveStatus.enabled ? " (live disabled)" : ""}
          </button>{" "}
          <span className="badge">{executionMode === "paper" ? "Simulated orders" : "LIVE · confirm every order"}</span>{" "}
          <span className="badge">{Object.keys(instruments).length} symbols</span>{" "}
          <button onClick={refreshInstruments}>Refresh symbols</button>{" "}
          {!auth.authenticated && (
            <button className="primary" onClick={login}>Login with Upstox</button>
          )}
        </div>
      </header>
      {instrumentError && <div className="err" role="alert">{instrumentError}</div>}
      {executionMode === "live" && (
        <div className="err" role="alert">
          Live mode: only manual orders use real Upstox execution. Every order requires confirmation.
          Automated strategies remain paper-only. Maximum order value: ₹{Number(liveStatus.max_order_value).toLocaleString("en-IN")}.
        </div>
      )}
      <nav>
        {Object.keys(TABS).map((t) => (
          <button key={t} className={t === tab ? "on" : ""} onClick={() => setTab(t)}>{t}</button>
        ))}
      </nav>
      <main>
        <Page instruments={instruments} executionMode={executionMode} liveStatus={liveStatus} />
      </main>
    </>
  );
}
