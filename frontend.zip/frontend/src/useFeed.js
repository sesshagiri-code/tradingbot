import { useEffect, useState } from "react";

const MAX_RETRY_MS = 30_000;

export function useFeed(path = "/api/ws/paper") {
  const [snapshot, setSnapshot] = useState(null);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    let socket;
    let retryTimer;
    let retryMs = 1000;
    let closed = false;

    const connect = () => {
      const proto = window.location.protocol === "https:" ? "wss" : "ws";
      socket = new WebSocket(`${proto}://${window.location.host}${path}`);
      socket.onopen = () => {
        retryMs = 1000;
        setConnected(true);
      };
      socket.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type === "snapshot") setSnapshot(data);
        } catch {
          // ignore malformed frames
        }
      };
      socket.onclose = () => {
        setConnected(false);
        if (closed) return;
        retryTimer = setTimeout(connect, retryMs);
        retryMs = Math.min(retryMs * 2, MAX_RETRY_MS);
      };
    };

    connect();
    return () => {
      closed = true;
      clearTimeout(retryTimer);
      socket?.close();
    };
  }, [path]);

  return { snapshot, connected };
}

export const isOk = (section) => Boolean(section) && !section.error;
