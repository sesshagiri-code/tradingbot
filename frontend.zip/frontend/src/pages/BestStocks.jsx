import React, { useState } from "react";
import { api, fmt } from "../api.js";

export default function BestStocks() {
  const [universe, setUniverse] = useState("nifty50");
  const [days, setDays] = useState(365);
  const [limit, setLimit] = useState(20);
  const [scan, setScan] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [autoStatus, setAutoStatus] = useState(null);
  const [autoError, setAutoError] = useState("");
  const [autoBusy, setAutoBusy] = useState(false);
  const [intervalMinutes, setIntervalMinutes] = useState(60);

  const refreshAutoStatus = async () => {
    try {
      setAutoStatus(await api("/paper/best-stocks/auto"));
      setAutoError("");
    } catch (e) {
      setAutoError(e.message);
    }
  };

  React.useEffect(() => {
    refreshAutoStatus();
    const timer = setInterval(refreshAutoStatus, 15000);
    return () => clearInterval(timer);
  }, []);

  const runScan = async () => {
    setBusy(true);
    setError("");
    try {
      const query = new URLSearchParams({ universe, days, limit });
      setScan(await api(`/stocks/screener?${query}`));
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  const autoConfig = {
    universe,
    days: Math.max(300, days),
    interval_minutes: intervalMinutes,
    max_positions: 5,
    allocation_pct: 20,
    entry_threshold: 0.55,
    exit_threshold: 0.45,
    minimum_technical_score: 50,
  };

  const runPaperCycle = async () => {
    setAutoBusy(true);
    setAutoError("");
    try {
      const result = await api("/paper/best-stocks/run", {
        method: "POST",
        body: autoConfig,
      });
      const status = await api("/paper/best-stocks/auto");
      setAutoStatus({ ...status, last_result: result, last_error: null });
    } catch (e) {
      setAutoError(e.message);
    } finally {
      setAutoBusy(false);
    }
  };

  const togglePaperAuto = async () => {
    setAutoBusy(true);
    setAutoError("");
    const enabled = !autoStatus?.running;
    try {
      const result = await api("/paper/best-stocks/auto", {
        method: "POST",
        body: enabled ? { ...autoConfig, enabled } : { enabled },
      });
      setAutoStatus(result);
    } catch (e) {
      setAutoError(e.message);
    } finally {
      setAutoBusy(false);
    }
  };

  return (
    <>
      <section className="card">
        <h2>Best Stocks</h2>
        <p className="note">
          Each scan trains Random Forest and XGBoost on historical daily candles with walk-forward
          validation. Ranking combines their consensus next-session probability with technical
          indicators; this is not a return prediction or a guarantee. Requires Upstox login and real
          market data. A full-index scan may take a little time.
        </p>
        <div className="row">
          <label>Universe
            <select value={universe} onChange={(event) => setUniverse(event.target.value)}>
              <option value="nifty50">NIFTY 50</option>
              <option value="sensex">Sensex</option>
              <option value="core">Core symbols</option>
            </select>
          </label>
          <label>History (days)
            <input type="number" min="60" max="3650" value={days} onChange={(event) => setDays(Number(event.target.value))} />
          </label>
          <label>Show top
            <select value={limit} onChange={(event) => setLimit(Number(event.target.value))}>
              {[10, 20, 50].map((value) => <option key={value} value={value}>{value}</option>)}
            </select>
          </label>
          <button className="primary" disabled={busy} onClick={runScan}>
            {busy ? "Scanning…" : "Find stocks"}
          </button>
        </div>
        {error && <div className="err" role="alert">{error}</div>}
        {scan && (
          <>
            <p className="note">
              Scanned {scan.scanned} symbols; ranked {scan.returned}. Data: {scan.data_source}.
              {scan.errors && Object.keys(scan.errors).length > 0
                ? ` ${Object.keys(scan.errors).length} symbols were skipped because data was unavailable.`
                : ""}
            </p>
            {scan.results.length === 0 ? (
              <div className="note">No symbols had enough valid daily candles to rank.</div>
            ) : (
              <div className="table-scroll">
                <table>
                  <thead>
                    <tr>
                      <th>#</th><th>Symbol</th><th>Rank score</th><th>Tech</th><th>RF P(up)</th>
                      <th>RF AUC</th><th>XGBoost P(up)</th><th>XGBoost AUC</th>
                      <th>Ensemble</th><th>Setup</th><th>Close</th>
                      <th>20d return</th><th>RSI</th><th>ATR %</th><th>Vol / avg</th>
                    </tr>
                  </thead>
                  <tbody>
                    {scan.results.map((stock, index) => (
                      <tr key={stock.symbol}>
                        <td>{index + 1}</td>
                        <td>{stock.symbol}</td>
                        <td>{fmt(stock.ranking_score)}</td>
                        <td>{fmt(stock.technical_score)}</td>
                        <td>{stock.model_predictions?.random_forest ? `${fmt(stock.model_predictions.random_forest.prob_up * 100)}%` : "n/a"}</td>
                        <td>{fmt(stock.model_predictions?.random_forest?.validation?.auc)}</td>
                        <td>{stock.model_predictions?.xgboost ? `${fmt(stock.model_predictions.xgboost.prob_up * 100)}%` : "n/a"}</td>
                        <td>{fmt(stock.model_predictions?.xgboost?.validation?.auc)}</td>
                        <td>{stock.ensemble_probability_up == null ? "n/a" : `${fmt(stock.ensemble_probability_up * 100)}%`}</td>
                        <td className={stock.setup === "strong" ? "up" : stock.setup === "weak" ? "dn" : ""}>{stock.setup}</td>
                        <td>{fmt(stock.close)}</td>
                        <td className={stock.return_20d_pct >= 0 ? "up" : "dn"}>{fmt(stock.return_20d_pct)}%</td>
                        <td>{fmt(stock.rsi_14)}</td>
                        <td>{fmt(stock.atr_14_pct)}%</td>
                        <td>{stock.volume_ratio == null ? "–" : `${fmt(stock.volume_ratio)}×`}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            {scan.errors && Object.keys(scan.errors).length > 0 && (
              <details className="scan-errors">
                <summary>Show skipped symbols</summary>
                <ul>{Object.entries(scan.errors).map(([name, message]) => <li key={name}>{name}: {message}</li>)}</ul>
              </details>
            )}
            {scan.results.some((stock) => Object.keys(stock.model_errors || {}).length > 0) && (
              <details className="scan-errors">
                <summary>Show model training/validation notes</summary>
                <ul>
                  {scan.results.flatMap((stock) =>
                    Object.entries(stock.model_errors || {}).map(([name, message]) => (
                      <li key={`${stock.symbol}-${name}`}>{stock.symbol} · {name}: {message}</li>
                    ))
                  )}
                </ul>
              </details>
            )}
          </>
        )}
      </section>
      <section className="card">
        <div className="row" style={{ justifyContent: "space-between" }}>
          <div>
            <h2>Best Stocks · Auto paper trade</h2>
            <p className="note">
              Simulated orders only. Buy if both models predict ≥55% and technical score is ≥50;
              exit if either predicts &lt;45%. Maximum 5 open positions, 20% allocation per symbol.
              Runs during NSE market hours using real quotes, slippage, and volume caps.
            </p>
          </div>
          <span className="badge">{autoStatus?.running ? "Auto paper trading on" : "Auto paper trading off"}</span>
        </div>
        <div className="row">
          <label>Rescan interval
            <select value={intervalMinutes} onChange={(event) => setIntervalMinutes(Number(event.target.value))}>
              {[15, 30, 60, 120, 240].map((value) => <option key={value} value={value}>{value} minutes</option>)}
            </select>
          </label>
          <button className="primary" disabled={autoBusy} onClick={runPaperCycle}>
            {autoBusy ? "Working…" : "Run one paper cycle"}
          </button>
          <button className={autoStatus?.running ? "sell" : "primary"} disabled={autoBusy} onClick={togglePaperAuto}>
            {autoBusy ? "Working…" : autoStatus?.running ? "Stop auto trade" : "Start auto trade"}
          </button>
        </div>
        {autoError && <div className="err" role="alert">{autoError}</div>}
        {autoStatus?.last_error && <div className="err" role="alert">Last cycle failed: {autoStatus.last_error}</div>}
        {autoStatus?.last_result && (
          <div className="note" aria-live="polite">
            Last cycle: {autoStatus.last_result.scanned ?? 0} scanned, {autoStatus.last_result.open_positions ?? 0} open.
            {autoStatus.last_result.actions?.length
              ? ` Actions: ${autoStatus.last_result.actions.map((action) => `${action.action} ${action.symbol}${action.order ? ` ${action.order.qty} @ ${fmt(action.order.price)}` : ""}`).join("; ")}`
              : " No paper orders placed."}
            {autoStatus.last_result.errors && Object.keys(autoStatus.last_result.errors).length > 0
              ? ` Errors: ${Object.entries(autoStatus.last_result.errors).map(([name, message]) => `${name}: ${message}`).join("; ")}`
              : ""}
          </div>
        )}
      </section>
    </>
  );
}
