import React, { useEffect, useState } from "react";
import { api, fmt } from "../api.js";

const DEFAULT_SYMBOLS = "RELIANCE, TCS, HDFCBANK, INFY";

function parseSymbols(text) {
  return [...new Set(text.split(/[\s,]+/).map((s) => s.trim().toUpperCase()).filter(Boolean))];
}

function ActionBadge({ action }) {
  const tone = action === "BUY" ? "buy" : action === "SELL" ? "sell" : "";
  return <span className={`pill ${tone}`}>{action}</span>;
}

const STRATEGY_PATHS = { rl: "/paper/rl", trend: "/paper/trend" };

export default function RLPaper() {
  const [strategy, setStrategy] = useState("rl");
  const [universe, setUniverse] = useState("nifty50");
  const [allocationPct, setAllocationPct] = useState(20);
  const [maxPositions, setMaxPositions] = useState(5);
  const [intervalMinutes, setIntervalMinutes] = useState(60);
  const [trendDays, setTrendDays] = useState(14);
  const [symbolsText, setSymbolsText] = useState(DEFAULT_SYMBOLS);
  const [timesteps, setTimesteps] = useState(50000);
  const [status, setStatus] = useState(null);
  const [training, setTraining] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [stage, setStage] = useState("");

  const isRl = strategy === "rl";
  const base = STRATEGY_PATHS[strategy];

  const refreshStatus = async () => {
    try {
      setStatus(await api(`${base}/auto`));
    } catch (e) {
      setError(e.message);
    }
  };

  useEffect(() => {
    setStatus(null);
    setError("");
    refreshStatus();
    const timer = setInterval(refreshStatus, 15000);
    return () => clearInterval(timer);
  }, [base]);

  const config = {
    universe,
    days: 730,
    interval_minutes: intervalMinutes,
    max_positions: maxPositions,
    allocation_pct: allocationPct,
    trend_days: trendDays,
  };

  const run = async (label, action) => {
    setBusy(true);
    setStage(label);
    setError("");
    try {
      await action();
      await refreshStatus();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
      setStage("");
    }
  };

  const train = () =>
    run("Training PPO policies on real Upstox data. This can take several minutes…", async () => {
      const symbols = parseSymbols(symbolsText);
      if (!symbols.length) throw new Error("Enter at least one NSE symbol to train.");
      setTraining(await api("/paper/rl/train", {
        method: "POST",
        body: { symbols, days: 730, total_timesteps: timesteps, seed: 42 },
      }));
    });

  const runOnce = () =>
    run("Running one paper cycle…", async () => {
      const result = await api(`${base}/run`, { method: "POST", body: config });
      setStatus((prev) => ({ ...(prev || {}), last_result: result, last_error: null }));
    });

  const toggleAuto = () =>
    run(status?.running ? "Stopping…" : "Starting paper auto trading…", async () => {
      await api(`${base}/auto`, {
        method: "POST",
        body: status?.running ? { enabled: false } : { ...config, enabled: true },
      });
    });

  const result = status?.last_result;

  return (
    <>
      <div className="card rl-hero">
        <div>
          <h2>{isRl ? "RL Paper Trading" : "Trend Paper Trading"}</h2>
          <p className="note">
            {isRl
              ? "A PPO policy per stock decides hold, long, or flat on daily bars."
              : `Long when the last completed close is above its ${trendDays}-day average, otherwise flat.`}{" "}
            All orders are simulated; live trading is never used here. Results are not evidence of an edge until you have
            reviewed forward paper performance.
          </p>
        </div>
        <div className="rl-status">
          <span className={`dot ${status?.running ? "on" : ""}`} aria-hidden="true" />
          <b>{status?.running ? "Auto paper trading running" : "Stopped"}</b>
          <span className="badge">Paper only</span>
        </div>
      </div>

      {error && <div className="err" role="alert">{error}</div>}
      {busy && <div className="card note" role="status">⏳ {stage}</div>}

      <div className="grid">
        <div className="stat"><span>Open positions</span><b>{result?.open_positions ?? "–"}</b></div>
        <div className="stat"><span>Max positions</span><b>{result?.max_positions ?? maxPositions}</b></div>
        <div className="stat"><span>Last actions</span><b>{result?.actions?.length ?? "–"}</b></div>
        <div className="stat"><span>Errors</span><b>{result ? Object.keys(result.errors || {}).length : "–"}</b></div>
      </div>

      <div className="card">
        <h2>Trading controls</h2>
        <div className="row">
          <label>Strategy
            <select value={strategy} onChange={(e) => setStrategy(e.target.value)} disabled={busy}>
              <option value="rl">PPO policy (RL)</option>
              <option value="trend">Trend MA</option>
            </select>
          </label>
          <label>Universe
            <select value={universe} onChange={(e) => setUniverse(e.target.value)} disabled={busy}>
              <option value="nifty50">NIFTY 50</option>
              <option value="sensex">SENSEX</option>
              <option value="core">Core</option>
            </select>
          </label>
          {!isRl && (
            <label>Trend average (days)
              <input type="number" min="2" max="200" value={trendDays}
                onChange={(e) => setTrendDays(Number(e.target.value))} disabled={busy} />
            </label>
          )}
          <label>Allocation per stock (%)
            <input type="number" min="1" max="20" value={allocationPct}
              onChange={(e) => setAllocationPct(Number(e.target.value))} disabled={busy} />
          </label>
          <label>Max positions
            <input type="number" min="1" max="5" value={maxPositions}
              onChange={(e) => setMaxPositions(Number(e.target.value))} disabled={busy} />
          </label>
          <label>Check every (min)
            <input type="number" min="15" max="360" value={intervalMinutes}
              onChange={(e) => setIntervalMinutes(Number(e.target.value))} disabled={busy} />
          </label>
          <button className="primary" onClick={runOnce} disabled={busy}>Run one paper cycle</button>
          <button className={status?.running ? "primary sell" : "primary buy"} onClick={toggleAuto} disabled={busy}>
            {status?.running ? "Stop auto trading" : "Start auto trading"}
          </button>
        </div>
        <p className="note">
          Runs only during NSE market hours. Requires a connected Upstox account
          {isRl ? " and trained policies." : "."}
        </p>
      </div>

      {isRl && (
        <div className="card">
          <h2>Train policies</h2>
          <div className="row">
            <label style={{ flex: 1, minWidth: 260 }}>NSE symbols (comma separated, up to 10)
              <input value={symbolsText} onChange={(e) => setSymbolsText(e.target.value)} disabled={busy} />
            </label>
            <label>Timesteps
              <input type="number" min="5000" max="200000" step="5000" value={timesteps}
                onChange={(e) => setTimesteps(Number(e.target.value))} disabled={busy} />
            </label>
            <button className="primary" onClick={train} disabled={busy}>Train PPO policies</button>
          </div>
          {training && (
            <div className="rl-train">
              <p className="note">
                Trained {training.trained.length} policy(ies)
                {Object.keys(training.errors || {}).length ? `, ${Object.keys(training.errors).length} failed` : ""}.
              </p>
              {Object.entries(training.errors || {}).map(([symbol, message]) => (
                <div key={symbol} className="err">{symbol}: {message}</div>
              ))}
            </div>
          )}
        </div>
      )}

      {status?.last_error && <div className="err" role="alert">{status.last_error}</div>}

      {result && (
        <div className="card">
          <h2>Latest cycle</h2>
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th>Symbol</th><th>Action</th><th>Qty</th><th>Price</th><th>Reason</th>
                </tr>
              </thead>
              <tbody>
                {result.actions.length === 0 && (
                  <tr><td colSpan="5" className="note">No actions this cycle.</td></tr>
                )}
                {result.actions.map((a) => (
                  <tr key={a.symbol + a.action}>
                    <td>{a.symbol}</td>
                    <td><ActionBadge action={a.action} /></td>
                    <td>{a.order ? a.order.qty : "–"}</td>
                    <td>{a.order ? fmt(a.order.price) : "–"}</td>
                    <td className="reason">{a.reason || a.order?.note || ""}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {Object.keys(result.errors || {}).length > 0 && (
            <div className="scan-errors">
              {Object.entries(result.errors).map(([symbol, message]) => (
                <div key={symbol}>{symbol}: {message}</div>
              ))}
            </div>
          )}
        </div>
      )}
    </>
  );
}
