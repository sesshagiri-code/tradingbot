import React, { useState } from "react";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from "recharts";
import { api, fmt, cls } from "../api.js";
import SymbolPicker from "../components/SymbolPicker.jsx";

const iso = (d) => d.toISOString().slice(0, 10);
const yearsAgo = (n) => { const d = new Date(); d.setFullYear(d.getFullYear() - n); return iso(d); };
const daysAgo = (n) => { const d = new Date(); d.setDate(d.getDate() - n); return iso(d); };

export default function Backtest({ instruments }) {
  const [mode, setMode] = useState("single");
  const [f, setF] = useState({
    symbol: "RELIANCE", interval: "day", start: yearsAgo(4), end: iso(new Date()),
    strategy: "ml", capital: 100000, fee_pct: 0.03, slippage_pct: 0.02, stop_loss_pct: 0, trailing_stop_pct: 0, trailing_profit_pct: 0, trail_profit_activate_pct: 5, source: "auto",
    model: "gradient_boosting", threshold: 0.52, fast: 10, slow: 30, rsi_buy: 30, rsi_sell: 55,
    lookback: 20, retest_bars: 3, volume_multiple: 1.2, minimum_rsi: 50,
    ml_threshold: 0.55, risk_pct: 1, max_position_pct: 20, max_stop_loss_pct: 2,
  });
  const [res, setRes] = useState(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === "number" ? +e.target.value : e.target.value });

  const run = async () => {
    setBusy(true); setErr("");
    const params = {
      model: f.model, threshold: f.threshold, fast: f.fast, slow: f.slow,
      rsi_buy: f.rsi_buy, rsi_sell: f.rsi_sell, lookback: f.lookback,
      retest_bars: f.retest_bars, volume_multiple: f.volume_multiple,
      minimum_rsi: f.minimum_rsi, ml_threshold: f.ml_threshold,
      risk_pct: f.risk_pct, max_position_pct: f.max_position_pct,
      max_stop_loss_pct: f.max_stop_loss_pct,
    };
    try {
      if (mode === "nifty50") {
        const { symbol, interval, ...portfolioConfig } = f;
        setRes(await api("/backtest/nifty50", {
          method: "POST",
          body: { ...portfolioConfig, strategy: ["ml", "sma_cross", "rsi"].includes(f.strategy) ? f.strategy : "ml", params },
        }));
      } else {
        setRes(await api("/backtest", { method: "POST", body: { ...f, params } }));
      }
    } catch (e) { setErr(e.message); setRes(null); }
    setBusy(false);
  };
  const m = res?.metrics;

  return (
    <>
      <div className="card">
        <div className="row">
          <label>Backtest type<select value={mode} onChange={(event) => {
            const nextMode = event.target.value;
            setMode(nextMode);
            setRes(null);
            setErr("");
            if (nextMode === "nifty50") {
              setF({
                ...f,
                interval: "day",
                capital: f.capital === 100000 ? 1000000 : f.capital,
                strategy: ["ml", "sma_cross", "rsi"].includes(f.strategy) ? f.strategy : "ml",
              });
            }
          }}><option value="single">Single stock</option><option value="nifty50">NIFTY 50 portfolio</option></select></label>
          {mode === "single" && <SymbolPicker symbol={f.symbol} instruments={instruments} onChange={(symbol) => setF({ ...f, symbol })} />}
          {mode === "single" ? (
            <label>Interval<select value={f.interval} onChange={set("interval")}><option value="day">Daily</option><option value="30minute">30 min</option><option value="5minute">5 min</option><option value="1minute">1 min</option></select></label>
          ) : <span className="badge">Daily bars · 50-stock portfolio</span>}
          <label>Start<input type="date" value={f.start} onChange={set("start")} /></label>
          <label>End<input type="date" value={f.end} onChange={set("end")} /></label>
          <label>Data source<select value={f.source} onChange={set("source")}><option value="auto">Auto (Upstox→demo)</option><option value="upstox">Upstox only</option><option value="synthetic">Synthetic demo</option></select></label>
          <label>Strategy<select value={f.strategy} onChange={(e) => {
            const strategy = e.target.value;
            setF({
              ...f,
              strategy,
              ...(strategy === "breakout_5m" ? { interval: "5minute", start: daysAgo(28) } : {}),
            });
          }}><option value="ml">ML (walk-forward)</option><option value="sma_cross">SMA crossover</option><option value="rsi">RSI mean-reversion</option>{mode === "single" && <option value="breakout_5m">5-minute breakout</option>}</select></label>
        </div>
        <div className="row" style={{ marginTop: 12 }}>
          <label>{mode === "nifty50" ? "Portfolio capital ₹" : "Capital ₹"}<input type="number" value={f.capital} onChange={set("capital")} /></label>
          <label>Fee %<input type="number" step="0.01" value={f.fee_pct} onChange={set("fee_pct")} /></label>
          <label>Slippage %<input type="number" step="0.01" value={f.slippage_pct} onChange={set("slippage_pct")} /></label>
          <label>Stop-loss % (0=off)<input type="number" step="0.5" value={f.stop_loss_pct} onChange={set("stop_loss_pct")} /></label>
          <label>Trailing stop % (0=off)<input type="number" step="0.5" value={f.trailing_stop_pct} onChange={set("trailing_stop_pct")} /></label>
          <label>Profit lock: activate at +%<input type="number" step="0.5" value={f.trail_profit_activate_pct} onChange={set("trail_profit_activate_pct")} /></label>
          <label>Profit lock: pullback % (0=off)<input type="number" step="0.5" value={f.trailing_profit_pct} onChange={set("trailing_profit_pct")} /></label>
          {f.strategy === "ml" && <>
            <label>Model<select value={f.model} onChange={set("model")}><option value="gradient_boosting">Gradient Boosting</option><option value="random_forest">Random Forest</option></select></label>
            <label>Buy if P(up) &gt;<input type="number" step="0.01" value={f.threshold} onChange={set("threshold")} /></label>
          </>}
          {f.strategy === "sma_cross" && <>
            <label>Fast<input type="number" value={f.fast} onChange={set("fast")} /></label>
            <label>Slow<input type="number" value={f.slow} onChange={set("slow")} /></label>
          </>}
          {f.strategy === "rsi" && <>
            <label>Buy RSI &lt;<input type="number" value={f.rsi_buy} onChange={set("rsi_buy")} /></label>
            <label>Sell RSI &gt;<input type="number" value={f.rsi_sell} onChange={set("rsi_sell")} /></label>
          </>}
          {f.strategy === "breakout_5m" && <>
            <label>Resistance lookback (bars)<input type="number" min="2" value={f.lookback} onChange={set("lookback")} /></label>
            <label>Retest window (bars)<input type="number" min="1" value={f.retest_bars} onChange={set("retest_bars")} /></label>
            <label>Volume vs baseline (×)<input type="number" min="0.1" step="0.1" value={f.volume_multiple} onChange={set("volume_multiple")} /></label>
            <label>Minimum RSI<input type="number" min="0" max="100" value={f.minimum_rsi} onChange={set("minimum_rsi")} /></label>
            <label>Minimum ML P(up)<input type="number" min="0" max="1" step="0.01" value={f.ml_threshold} onChange={set("ml_threshold")} /></label>
            <label>Risk per trade %<input type="number" min="0.1" max="5" step="0.1" value={f.risk_pct} onChange={set("risk_pct")} /></label>
            <label>Maximum allocation %<input type="number" min="0.1" max="100" step="1" value={f.max_position_pct} onChange={set("max_position_pct")} /></label>
            <label>Maximum stop distance %<input type="number" min="0.1" max="10" step="0.1" value={f.max_stop_loss_pct} onChange={set("max_stop_loss_pct")} /></label>
          </>}
          <button className="primary" disabled={busy} onClick={run}>{busy ? (mode === "nifty50" ? "Testing up to 50 stocks…" : "Running…") : mode === "nifty50" ? "Run NIFTY 50 backtest" : "Run backtest"}</button>
        </div>
        {mode === "nifty50" && <p className="note">Daily long-only portfolio backtest across the 50 NIFTY 50 constituents. Capital is allocated equally across all 50; unavailable or failed stocks remain in cash and are reported. This makes up to 50 historical-data requests and may take a few minutes. Use Upstox-only data for meaningful results; synthetic data is for demonstration.</p>}
        {err && <div className="err">{err}</div>}
      </div>

      {res && (
        <>
          <div className="card">
            <div className="grid">
              <Stat l="Total return %" v={m.total_return_pct} c />
              <Stat l="Buy & hold %" v={m.buy_hold_return_pct} c />
              <Stat l="CAGR %" v={m.cagr_pct} c />
              <Stat l="Sharpe" v={m.sharpe} />
              <Stat l="Max drawdown %" v={m.max_drawdown_pct} c />
              <Stat l="Trades" v={m.num_trades} d={0} />
              <Stat l="Win rate %" v={m.win_rate_pct} />
              <Stat l="Profit factor" v={m.profit_factor} />
              <Stat l="Final equity ₹" v={m.final_equity} />
              {res.ml?.auc != null && <Stat l="ML OOS AUC" v={res.ml.auc} d={3} />}
              {res.ml?.accuracy != null && <Stat l="ML OOS accuracy" v={res.ml.accuracy} d={3} />}
              {res.breakout && <Stat l="Breakout entries" v={res.breakout.entries} d={0} />}
            </div>
            <p className="note">{mode === "nifty50" ? `${res.symbols_tested} stocks tested of ${res.symbols_requested} requested` : `${res.bars} bars`} · data: {res.data_source}{res.data_source === "synthetic" && " (demo data – results are not real market performance)"}. Signals execute on next bar open. ML metrics are out-of-sample; the backtest starts after the initial training window.{mode === "nifty50" && ` ${res.capital_allocation}`}</p>
            {res.breakout && <p className="note">OI: {res.breakout.oi_status}. A trade requires a close above prior resistance, a holding retest within {res.breakout.retest_window_bars} bars, above-baseline breakout volume, RSI/VWAP confirmation, and an out-of-sample ML score. Stops use the retest low; entries exceeding the configured stop or risk limits are rejected.</p>}
          </div>
          {mode === "nifty50" && (
            <>
              {Object.keys(res.errors || {}).length > 0 && (
                <details className="card">
                  <summary>{Object.keys(res.errors).length} symbols were skipped</summary>
                  <ul>{Object.entries(res.errors).map(([symbol, message]) => <li key={symbol}>{symbol}: {message}</li>)}</ul>
                </details>
              )}
              <div className="card">
                <h3 style={{ marginTop: 0 }}>Per-stock results</h3>
                <div className="table-scroll">
                  <table>
                    <thead><tr><th>Symbol</th><th>Return %</th><th>Buy & hold %</th><th>Trades</th><th>Win rate %</th><th>Max drawdown %</th><th>Final allocation ₹</th></tr></thead>
                    <tbody>{res.stocks.map((stock) => (
                      <tr key={stock.symbol}>
                        <td>{stock.symbol}</td><td className={cls(stock.total_return_pct)}>{fmt(stock.total_return_pct)}</td>
                        <td className={cls(stock.buy_hold_return_pct)}>{fmt(stock.buy_hold_return_pct)}</td>
                        <td>{stock.num_trades}</td><td>{fmt(stock.win_rate_pct)}</td>
                        <td className={cls(stock.max_drawdown_pct)}>{fmt(stock.max_drawdown_pct)}</td>
                        <td>{fmt(stock.final_equity)}</td>
                      </tr>
                    ))}</tbody>
                  </table>
                </div>
              </div>
            </>
          )}
          <div className="card" style={{ height: 380 }}>
            <ResponsiveContainer>
              <LineChart data={res.equity_curve}>
                <CartesianGrid stroke="#2a3350" strokeDasharray="3 3" />
                <XAxis dataKey="time" tickFormatter={(t) => t.slice(0, 10)} minTickGap={60} />
                <YAxis domain={["auto", "auto"]} />
                <Tooltip contentStyle={{ background: "#181f30", border: "1px solid #2a3350" }} />
                <Legend />
                <Line dataKey="equity" name="Strategy" stroke="#26a69a" dot={false} strokeWidth={2} />
                <Line dataKey="buy_hold" name="Buy & hold" stroke="#8c95b0" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="card">
            <h3 style={{ marginTop: 0 }}>Trades</h3>
            <div style={{ maxHeight: 320, overflow: "auto" }}>
              <table>
                <thead><tr>{mode === "nifty50" && <th>Symbol</th>}<th>Time</th><th>Side</th><th>Qty</th><th>Price</th><th>P&L</th></tr></thead>
                <tbody>{res.trades.map((t, i) => (
                  <tr key={i}>{mode === "nifty50" && <td>{t.symbol}</td>}<td>{t.time}</td><td>{t.side}</td><td>{t.qty}</td><td>{fmt(t.price)}</td><td className={cls(t.pnl)}>{fmt(t.pnl)}</td></tr>
                ))}</tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </>
  );
}

function Stat({ l, v, c, d = 2 }) {
  return <div className="stat"><span>{l}</span><b className={c ? cls(v) : ""}>{fmt(v, d)}</b></div>;
}
