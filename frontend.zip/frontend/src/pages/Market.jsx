import React, { useEffect, useState } from "react";
import { ResponsiveContainer, ComposedChart, Line, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { api } from "../api.js";
import SymbolPicker from "../components/SymbolPicker.jsx";

export default function Market({ instruments }) {
  const [symbol, setSymbol] = useState("RELIANCE");
  const [interval, setInterval_] = useState("day");
  const [days, setDays] = useState(365);
  const [data, setData] = useState(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const load = async () => {
    setBusy(true); setErr("");
    try {
      setData(await api(`/candles?symbol=${encodeURIComponent(symbol)}&interval=${interval}&days=${days}`));
    } catch (e) { setErr(e.message); }
    setBusy(false);
  };
  useEffect(() => { load(); }, []); // eslint-disable-line

  return (
    <div className="card">
      <div className="row">
        <SymbolPicker symbol={symbol} instruments={instruments} onChange={setSymbol} />
        <label>Interval
          <select value={interval} onChange={(e) => setInterval_(e.target.value)}>
            <option value="day">Daily</option><option value="30minute">30 min</option><option value="5minute">5 min</option><option value="1minute">1 min</option>
          </select>
        </label>
        <label>Days back<input type="number" value={days} onChange={(e) => setDays(+e.target.value)} /></label>
        <button className="primary" disabled={busy} onClick={load}>Load</button>
        {data && <span className="badge">source: {data.source}</span>}
      </div>
      {err && <div className="err">{err}</div>}
      {data && (
        <div style={{ height: 420, marginTop: 16 }}>
          <ResponsiveContainer>
            <ComposedChart data={data.candles}>
              <CartesianGrid stroke="#2a3350" strokeDasharray="3 3" />
              <XAxis dataKey="time" tickFormatter={(t) => t.slice(0, 10)} minTickGap={50} />
              <YAxis yAxisId="p" domain={["auto", "auto"]} />
              <YAxis yAxisId="v" orientation="right" hide />
              <Tooltip contentStyle={{ background: "#181f30", border: "1px solid #2a3350" }} />
              <Bar yAxisId="v" dataKey="volume" fill="#2a3350" />
              <Line yAxisId="p" dataKey="close" stroke="#5c7cfa" dot={false} strokeWidth={2} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}
