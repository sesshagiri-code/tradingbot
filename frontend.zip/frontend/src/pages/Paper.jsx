import React, { useCallback, useEffect, useState } from "react";
import { api, fmt, cls } from "../api.js";
import SymbolPicker from "../components/SymbolPicker.jsx";
import { isOk, useFeed } from "../useFeed.js";

export default function Paper({ instruments, executionMode = "paper", liveStatus }) {
  const [acct, setAcct] = useState(null);
  const [symbol, setSymbol] = useState("RELIANCE");
  const [qty, setQty] = useState(10);
  const [model, setModel] = useState("gradient_boosting");
  const [alloc, setAlloc] = useState(20);
  const [maxPositionPct, setMaxPositionPct] = useState(20);
  const [maxOpenPositions, setMaxOpenPositions] = useState(5);
  const [riskDirty, setRiskDirty] = useState(false);
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const feed = useFeed();

  const refresh = useCallback(() => api("/paper/account").then(setAcct).catch((e) => setErr(e.message)), []);
  useEffect(() => { refresh(); if (feed.connected) return undefined; const t = setInterval(refresh, 15000); return () => clearInterval(t); }, [refresh, feed.connected]);
  useEffect(() => {
    if (isOk(feed.snapshot?.paper_account)) setAcct(feed.snapshot.paper_account);
  }, [feed.snapshot]);
  useEffect(() => {
    if (acct?.risk_limits && !riskDirty) {
      setMaxPositionPct(acct.risk_limits.max_position_pct);
      setMaxOpenPositions(acct.risk_limits.max_open_positions);
    }
  }, [acct, riskDirty]);

  const act = async (fn) => {
    setBusy(true); setErr(""); setMsg("");
    try { setMsg(await fn()); await refresh(); } catch (e) { setErr(e.message); }
    setBusy(false);
  };
  const order = (side) => {
    const live = executionMode === "live";
    if (live && !liveStatus?.enabled) {
      setErr("Live trading is disabled by the backend.");
      return;
    }
    if (
      live
      && !window.confirm(
        `Submit a REAL ${side} order for ${qty} ${symbol} through Upstox? This may execute immediately.`
      )
    ) return;
    return act(async () => {
      const r = await api(live ? "/live/order" : "/paper/order", {
        method: "POST",
        body: { symbol, side, qty, ...(live ? { confirm: true } : {}) },
      });
      return live
        ? `Live ${side} order submitted for ${qty} ${symbol}. Verify its status and fill with Upstox.`
        : `${r.side} ${r.qty} @ ${fmt(r.price)} filled${r.learning_note ? ` · ${r.learning_note}` : ""}`;
    });
  };
  const closeSymbol = (p) => act(async () => {
    const r = await api("/paper/order", { method: "POST", body: { symbol: p.symbol, side: "SELL", qty: p.qty } });
    return `Closed ${r.qty} ${p.symbol} @ ${fmt(r.price)} · realized ${fmt(r.realized_pnl)}`;
  });
  const auto = () => act(async () => {
    const r = await api("/paper/auto-signal", { method: "POST", body: { symbol, model, allocation_pct: alloc } });
    const outcome = r.trade_outcome_probability == null ? "not trained yet" : r.trade_outcome_probability;
    const tech = r.technical ? `technical ${r.technical.score} (${r.technical.label})` : "";
    const why = r.why ? `\nWhy: ${r.why}` : "";
    const validation = r.outcome_model.validation
      ? ` · recent validation AUC=${r.outcome_model.validation.auc}`
      : "";
    return `P(up)=${r.prob_up} · P(profitable)=${outcome} · ${tech}${validation} → ${r.action}${r.price == null ? "" : ` @ ${fmt(r.price)}`} — ${r.reason} (data: ${r.data_source})${why}`;
  });
  const breakoutSignal = () => act(async () => {
    const r = await api("/paper/breakout-signal", {
      method: "POST",
      body: { symbol, model, allocation_pct: alloc },
    });
    const validation = r.ml_validation.auc == null
      ? "ML validation unavailable"
      : `walk-forward AUC=${r.ml_validation.auc}`;
    return `5m breakout ${r.action}${r.price == null ? "" : ` @ ${fmt(r.price)}`} · P(up)=${r.prob_up ?? "–"} · resistance=${fmt(r.resistance)} · stop=${fmt(r.stop_loss)} · ${validation} · OI ${r.breakout.oi_status} — ${r.reason}`;
  });
  const train = () => act(async () => {
    const r = await api("/paper/train", { method: "POST", body: { model } });
    const status = r.outcome_model;
    const dataErrors = Object.entries(r.reconstruction.data_errors)
      .map(([symbol, error]) => `${symbol}: ${error}`)
      .join("; ");
    const validation = status.validation
      ? ` Recent out-of-sample AUC ${status.validation.auc}, accuracy ${status.validation.accuracy}, Brier ${status.validation.brier_score}.`
      : "";
    return status.active
      ? `Outcome model ${status.signal_ready ? "ready" : "not taking buy signals"}: ${status.sample_count} completed trades across ${r.training_data.symbols} symbols (${r.training_data.paper} paper, ${r.training_data.backtest} backtest). ${r.checkpoint_saved ? "Validated checkpoint saved locally." : ""}${validation}${dataErrors ? ` Reconstruction errors: ${dataErrors}` : ""}`
      : `${status.reason}: ${status.sample_count}/${status.minimum_samples} examples; ${status.profitable_count} wins/${status.unprofitable_count} losses; need at least ${status.minimum_per_class} each.${dataErrors ? ` Reconstruction errors: ${dataErrors}` : ""}`;
  });
  const [trainDays, setTrainDays] = useState(365);
  const [universe, setUniverse] = useState("core");
  const [trainInterval, setTrainInterval] = useState("day");
  const autoTrainAll = () => act(async () => {
    const r = await api("/train/auto", { method: "POST", body: { days: trainDays, interval: trainInterval, universe } });
    const ok = Object.entries(r.models)
      .map(([name, m]) => `${name}: AUC ${m.auc ?? "–"}, acc ${m.accuracy ?? "–"} (${m.bars} bars)`)
      .join("; ");
    const errors = Object.entries(r.errors).map(([name, error]) => `${name}: ${error}`).join("; ");
    return `Auto-trained ${r.trained} models, ${r.failed} failed. ${ok}${errors ? ` Errors: ${errors}` : ""}`;
  });
  const [autoTrade, setAutoTrade] = useState(null);
  const refreshAutoTrade = useCallback(() => api("/paper/auto-trade").then(setAutoTrade).catch(() => {}), []);
  useEffect(() => { refreshAutoTrade(); if (feed.connected) return undefined; const t = setInterval(refreshAutoTrade, 15000); return () => clearInterval(t); }, [refreshAutoTrade, feed.connected]);
  useEffect(() => {
    if (isOk(feed.snapshot?.auto_trade)) setAutoTrade(feed.snapshot.auto_trade);
  }, [feed.snapshot]);
  const toggleAutoTrade = () => act(async () => {
    const enable = !autoTrade?.running;
    const r = await api("/paper/auto-trade", { method: "POST", body: { enabled: enable } });
    setAutoTrade(r);
    return enable
      ? "Auto trade started: points breakout, CPR breakout and agent. Paper orders only, during market hours (09:15–15:30 IST)."
      : "Auto trade stopped.";
  });
  const [openRealizedKey, setOpenRealizedKey] = useState(null);
  const [showRealized, setShowRealized] = useState(false);
  const [realized, setRealized] = useState(null);
  const refreshRealized = useCallback(() => api("/paper/realized").then(setRealized).catch((e) => setErr(e.message)), []);
  useEffect(() => {
    if (!showRealized && !openRealizedKey) return;
    refreshRealized();
    const t = setInterval(refreshRealized, 15000);
    return () => clearInterval(t);
  }, [showRealized, openRealizedKey, refreshRealized]);
  const technical = () => act(async () => {
    const r = await api("/ta/score", { method: "POST", body: { symbol } });
    return `${symbol} technical score ${r.score} (${r.label}) · RSI ${r.rsi14}`;
  });
  const decide = () => act(async () => {
    const r = await api("/decision", { method: "POST", body: { symbol, allocation_pct: alloc } });
    const c = r.components;
    return `${r.action} ${symbol} · score ${r.combined_score} (trend ${c.trend.score}, order flow ${c.order_flow.score ?? "n/a"}${c.order_flow.error ? ` [${c.order_flow.error}]` : ""}, news ${c.news.score} from ${c.news.headlines} headlines) — ${r.reason} Paper only.`;
  });
  const forwardCheck = () => act(async () => {
    const r = await api("/paper/forward-check", { method: "POST", body: { model, universe } });
    const symbols = r.predictions.map((p) => `${p.symbol}: P(up) ${p.prob_up}${p.recorded ? " recorded" : " already recorded"}`);
    const errors = Object.entries(r.errors).map(([name, error]) => `${name}: ${error}`);
    return `Forward check complete for ${universe}; ${r.scored_now} earlier forecasts scored. ${r.summary.scored} total scored / ${r.summary.pending} awaiting next daily candle; accuracy ${r.summary.accuracy ?? "–"}, Brier ${r.summary.brier_score ?? "–"}. ${symbols.join("; ")}${errors.length ? ` Errors: ${errors.join("; ")}` : ""} No orders placed.`;
  });
  const saveRisk = () => act(async () => {
    const settings = await api("/paper/risk-settings", {
      method: "POST",
      body: { max_position_pct: maxPositionPct, max_open_positions: maxOpenPositions },
    });
    setRiskDirty(false);
    return `Risk limits saved: ${settings.max_position_pct}% per symbol, ${settings.max_open_positions} open positions maximum.`;
  });
  const reset = () => confirm("Reset the paper balance, positions, and order history? Saved ML training examples will be kept.") && act(async () => { await api("/paper/reset", { method: "POST" }); return "Account reset; saved ML examples were kept"; });

  return (
    <>
      <div className="card">
        <div className="row">
          <SymbolPicker symbol={symbol} instruments={instruments} onChange={setSymbol} />
          <label>Qty<input type="number" min="1" value={qty} onChange={(e) => setQty(+e.target.value)} /></label>
          <button className="primary buy" disabled={busy} onClick={() => order("BUY")}>
            {executionMode === "live" ? "Live Buy" : "Buy"}
          </button>
          <button className="primary sell" disabled={busy} onClick={() => order("SELL")}>
            {executionMode === "live" ? "Live Sell" : "Sell"}
          </button>
          <span style={{ width: 24 }} />
          <label>ML model<select value={model} onChange={(e) => setModel(e.target.value)}><option value="gradient_boosting">Gradient Boosting</option><option value="random_forest">Random Forest</option></select></label>
          <label>Allocation %<input type="number" value={alloc} onChange={(e) => setAlloc(+e.target.value)} /></label>
          <label>Train interval<select value={trainInterval} onChange={(e) => setTrainInterval(e.target.value)}><option value="day">Daily</option><option value="5minute">5-minute</option></select></label>
          <label>Universe<select value={universe} onChange={(e) => setUniverse(e.target.value)}><option value="core">Core 9</option><option value="nifty50">Nifty 50</option><option value="sensex">Sensex</option><option value="index_all">Nifty 50 + Sensex</option></select></label>
          <label>Window (days, min 7)<input type="number" min="7" max={trainInterval === "day" ? 1095 : 90} value={trainDays} onChange={(e) => setTrainDays(+e.target.value)} /></label>
          <button disabled={busy} onClick={technical}>Technical score</button>
          <button className="primary" disabled={busy} onClick={decide}>Decide (trend + flow + news, paper)</button>
          <button className="primary" disabled={busy} onClick={toggleAutoTrade}>
            {autoTrade?.running ? "Stop auto trade" : "Auto trade (paper)"}
          </button>
          <button disabled={busy} onClick={autoTrainAll}>Auto train all models</button>
          <button disabled={busy} onClick={train}>Train from outcomes</button>
          <button disabled={busy} onClick={forwardCheck}>Forward check {universe} (no orders)</button>
          <button className="primary" disabled={busy} onClick={auto}>Run ML signal</button>
          <button className="primary" disabled={busy} onClick={breakoutSignal}>Run 5-minute breakout</button>
          <button className="primary" style={{ background: "#444" }} onClick={reset}>Reset</button>
        </div>
        {msg && <div className="up" style={{ marginTop: 8 }}>{msg}</div>}
        {err && <div className="err">{err}</div>}
        <p className="note">
          {executionMode === "live"
            ? `Manual Buy/Sell submits real Upstox orders after per-order confirmation (maximum order value ₹${Number(liveStatus?.max_order_value || 0).toLocaleString("en-IN")}). Automated strategies and this page's portfolio remain paper-only.`
            : "Manual Buy/Sell uses virtual money only; no real orders are sent to Upstox."}
          {" "}Risk: there is no proven edge, and intraday NSE trading loses money for most retail participants. Stops are polled, not streamed; a fast move can pass a stop between checks, and the stop monitor exits at the price seen. Fills include slippage and are capped at a share of recent 5-minute volume. The 5-minute breakout signal requires real candles and a walk-forward ML AUC above 0.5. It checks resistance, a holding retest, volume, RSI, VWAP, and the risk-based position limit; OI is skipped when reliable data is unavailable. Forward check never places orders.
        </p>
      </div>

      {acct && (
        <>
          <div className="card">
            <h3 style={{ marginTop: 0 }}>Portfolio risk limits</h3>
            <div className="row">
              <label>Maximum per symbol %<input type="number" min="1" max="100" step="1" value={maxPositionPct} onChange={(e) => { setMaxPositionPct(+e.target.value); setRiskDirty(true); }} /></label>
              <label>Maximum open positions<input type="number" min="1" max="9" step="1" value={maxOpenPositions} onChange={(e) => { setMaxOpenPositions(+e.target.value); setRiskDirty(true); }} /></label>
              <button disabled={busy || !riskDirty} onClick={saveRisk}>Save limits</button>
            </div>
            <p className="note">These limits are enforced by the backend for manual and ML buys. A position size is checked against current account equity and includes estimated buy fees.</p>
          </div>
          <div className="card grid">
            <S l="Equity ₹" v={acct.equity} /><S l="Cash ₹" v={acct.cash} /><S l="Invested ₹" v={acct.market_value} />
            <S l="Total P&L ₹" v={acct.total_pnl} c /><S l="Realized P&L ₹" v={acct.realized_pnl} c />
            <S l="Realized today ₹" v={acct.realized_today} c />
            <S l="Fees paid ₹" v={acct.total_fees} />
            <S l="Closed trades" v={acct.performance.closed_trades} d={0} />
            <S l="Average trade ₹" v={acct.performance.expectancy} c />
            <S l="Win rate %" v={acct.performance.win_rate_pct} />
            <S l="Profit factor" v={acct.performance.profit_factor} />
            <S l="Average win ₹" v={acct.performance.average_win} c />
            <S l="Average loss ₹" v={acct.performance.average_loss} c />
            <S l="Worst trade ₹" v={acct.performance.worst_trade} c />
            <S l="Current loss streak" v={acct.performance.current_loss_streak} d={0} />
          </div>
          <div className="card">
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <h3 style={{ marginTop: 0 }}>Paper account positions</h3>
              <button onClick={() => setShowRealized((v) => !v)}>{showRealized ? "Hide realized" : "Realized"}</button>
            </div>
            {executionMode === "live" && (
              <p className="note">These balances, positions, close actions, and order history are paper-only. Live broker positions are not shown on this page.</p>
            )}
            {acct.positions.length === 0 ? <p className="note">No open positions.</p> : (
              <table>
                <thead><tr><th>Symbol</th><th>Qty</th><th>Avg incl. fee</th><th>Stop-loss</th><th>LTP</th><th>Value</th><th>Portfolio %</th><th>Unrealized</th><th>Realized</th></tr></thead>
                <tbody>{acct.positions.map((p) => (
                                  <React.Fragment key={p.key}>
                                  <tr><td>{p.symbol}</td><td>{p.qty}</td><td>{fmt(p.avg_price)}</td><td>{fmt(p.stop_loss)}</td><td>{fmt(p.ltp)}</td><td>{fmt(p.market_value)}</td><td>{fmt(p.market_value / acct.equity * 100)}%</td><td className={cls(p.unrealized_pnl)}>{fmt(p.unrealized_pnl)}</td><td className={cls(p.realized_pnl)}>{fmt(p.realized_pnl)} <button disabled={busy} onClick={() => { setSymbol(p.symbol); setOpenRealizedKey(p.key); closeSymbol(p); }}>Realized</button></td></tr>
                  {openRealizedKey === p.key && (
                    <tr key={`${p.key}-realized`}><td colSpan={9}>{(() => {
                      const s = realized?.symbols.find((r) => r.key === p.key);
                      return s
                        ? `${p.symbol}: realized ₹${fmt(s.realized)} from ${s.closes} sell(s) — ${s.wins} win(s), ${s.losses} loss(es).`
                        : `${p.symbol}: no closed trades yet.`;
                    })()}</td></tr>
                  )}
                  </React.Fragment>
                ))}</tbody>
              </table>
            )}
          </div>
          {showRealized && (
            <div className="card">
              <h3 style={{ marginTop: 0 }}>Realized P&L by symbol</h3>
              {!realized ? <p className="note">Loading…</p> : realized.symbols.length === 0 ? (
                <p className="note">No closed trades yet.</p>
              ) : (
                <>
                  <p>Total realized ₹<span className={cls(realized.total_realized)}>{fmt(realized.total_realized)}</span></p>
                  <table>
                    <thead><tr><th>Symbol</th><th>Closes</th><th>Wins</th><th>Losses</th><th>Realized ₹</th></tr></thead>
                    <tbody>{realized.symbols.map((r) => (
                      <tr key={r.key}><td>{r.symbol}</td><td>{r.closes}</td><td>{r.wins}</td><td>{r.losses}</td><td className={cls(r.realized)}>{fmt(r.realized)}</td></tr>
                    ))}</tbody>
                  </table>
                </>
              )}
            </div>
          )}
          <div className="card">
            <h3 style={{ marginTop: 0 }}>Order history</h3>
            <div style={{ maxHeight: 300, overflow: "auto" }}>
              <table>
                <thead><tr><th>Time</th><th>Symbol</th><th>Side</th><th>Qty</th><th>Price</th><th>Fee</th><th>P&L</th><th>Note</th></tr></thead>
                <tbody>{acct.orders.map((o) => (
                  <tr key={o.id}><td>{o.ts}</td><td>{o.symbol}</td><td>{o.side}</td><td>{o.qty}</td><td>{fmt(o.price)}</td><td>{fmt(o.fee)}</td><td className={cls(o.realized_pnl)}>{fmt(o.realized_pnl)}</td><td>{o.note}</td></tr>
                ))}</tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </>
  );
}

function S({ l, v, c }) {
  return <div className="stat"><span>{l}</span><b className={c ? cls(v) : ""}>{fmt(v)}</b></div>;
}
