import React, { useCallback, useEffect, useRef, useState } from "react";
import { api, fmt } from "../api.js";
import { isOk, useFeed } from "../useFeed.js";

const UNIVERSES = [
  ["indices", "NIFTY 50 + BANK NIFTY indexes"],
  ["all", "NIFTY 50 + BANK NIFTY + NIFTY 50 stocks"],
  ["nifty50_index", "NIFTY 50 index"],
  ["banknifty_index", "BANK NIFTY index"],
  ["nifty50_stocks", "NIFTY 50 stocks"],
];

export default function Options({ executionMode = "paper", liveStatus }) {
  const [universe, setUniverse] = useState("indices");
  const [limit, setLimit] = useState(20);
  const [expiry, setExpiry] = useState("");
  const [expiries, setExpiries] = useState([]);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [autoUniverse, setAutoUniverse] = useState("indices");
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [lastUpdated, setLastUpdated] = useState(null);
  const busyRef = useRef(false);
  const [autoStatus, setAutoStatus] = useState(null);
  const [autoResult, setAutoResult] = useState(null);
  const [autoError, setAutoError] = useState("");
  const [autoBusy, setAutoBusy] = useState(false);
  const [positions, setPositions] = useState([]);
  const [livePositions, setLivePositions] = useState([]);
  const [orderBusy, setOrderBusy] = useState("");
  const [orderMessage, setOrderMessage] = useState("");
  const [orderError, setOrderError] = useState("");
  const feed = useFeed();
  const socketPositions = feed.connected && executionMode !== "live";

  const refreshPositions = useCallback(async () => {
    try {
      const live = executionMode === "live";
      const response = await api(live ? "/live/options/positions" : "/paper/options/positions");
      if (live) setLivePositions(response.positions);
      else setPositions(response.positions);
    } catch (e) {
      setOrderError(e.message);
    }
  }, [executionMode]);

  const refreshAutoStatus = useCallback(async () => {
    try {
      setAutoStatus(await api("/paper/options/auto"));
      setAutoError("");
    } catch (e) {
      setAutoError(e.message);
    }
  }, []);

  useEffect(() => {
    refreshAutoStatus();
    if (feed.connected) return undefined;
    const timer = setInterval(refreshAutoStatus, 15000);
    return () => clearInterval(timer);
  }, [refreshAutoStatus, feed.connected]);

  useEffect(() => {
    refreshPositions();
    if (socketPositions) return undefined;
    const positionTimer = setInterval(refreshPositions, 15000);
    return () => clearInterval(positionTimer);
  }, [refreshPositions, socketPositions]);

  useEffect(() => {
    if (isOk(feed.snapshot?.options_auto)) setAutoStatus(feed.snapshot.options_auto);
    if (!socketPositions) return;
    if (isOk(feed.snapshot?.paper_option_positions)) setPositions(feed.snapshot.paper_option_positions.positions);
  }, [feed.snapshot, socketPositions]);

  const scan = useCallback(async () => {
    if (busyRef.current) return;
    busyRef.current = true;
    setBusy(true);
    setError("");
    try {
      const params = { universe, limit };
      if (expiry) params.expiry = expiry;
      setResult(await api(`/options/recommendations?${new URLSearchParams(params)}`));
      setLastUpdated(new Date());
    } catch (e) {
      setError(e.message);
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  }, [universe, limit, expiry]);

  useEffect(() => {
    let cancelled = false;
    api(`/options/expiries?${new URLSearchParams({ underlying: "NIFTY 50" })}`)
      .then((data) => {
        if (cancelled) return;
        const dates = data.expiries || [];
        setExpiries(dates);
        if (dates.length) setExpiry((current) => current || dates[0]);
      })
      .catch(() => { if (!cancelled) setExpiries([]); });
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    scan();
    if (!autoRefresh) return undefined;
    const timer = setInterval(scan, 60_000);
    return () => clearInterval(timer);
  }, [scan, autoRefresh]);

  const autoConfig = {
    universe: autoUniverse,
    days: 365,
    interval_minutes: 60,
    max_positions: 3,
  };

  const runPaperCycle = async () => {
    setAutoBusy(true);
    setAutoError("");
    try {
      setAutoResult(await api("/paper/options/run", {
        method: "POST",
        body: autoConfig,
      }));
      await refreshAutoStatus();
    } catch (e) {
      setAutoError(e.message);
    } finally {
      setAutoBusy(false);
    }
  };

  const toggleAuto = async () => {
    setAutoBusy(true);
    setAutoError("");
    const enabled = !autoStatus?.running;
    try {
      setAutoStatus(await api("/paper/options/auto", {
        method: "POST",
        body: enabled ? { ...autoConfig, enabled } : { enabled },
      }));
    } catch (e) {
      setAutoError(e.message);
    } finally {
      setAutoBusy(false);
    }
  };

  const placeOptionOrder = async (item, side) => {
    const live = executionMode === "live";
    if (live && !liveStatus?.enabled) {
      setOrderError("Live trading is disabled by the backend.");
      return;
    }
    const key = item.instrument_key || item.key;
    const held = (live ? livePositions : positions).find((position) => position.key === key);
    const summary = side === "BUY"
      ? `Buy one lot of ${item.trading_symbol || item.instrument_key} through ${live ? "Upstox" : "the paper account"}?`
      : `Sell all ${held?.qty || 0} units of ${held?.symbol || item.trading_symbol} through ${live ? "Upstox" : "the paper account"}?`;
    const confirmation = live
      ? `REAL ORDER: ${summary}\nThis order may execute immediately.`
      : `${summary}\nPaper only. No live broker order will be sent.`;
    if (!window.confirm(confirmation)) return;
    setOrderBusy(key);
    setOrderError("");
    setOrderMessage("");
    try {
      const body = side === "BUY"
        ? {
          side,
          instrument_key: key,
          underlying: item.underlying,
          expiry: item.expiry,
          option_type: item.option_type,
          strike: item.strike,
          ...(live ? { confirm: true } : {}),
        }
        : { side, instrument_key: key, ...(live ? { confirm: true } : {}) };
      const response = await api(
        live ? "/live/options/order" : "/paper/options/order",
        { method: "POST", body }
      );
      setOrderMessage(live
        ? `Live ${response.side} order submitted for ${response.qty} ${item.trading_symbol || item.symbol || key}. Verify its status and fill with Upstox.`
        : `${response.order.side} ${response.order.qty} ${item.trading_symbol || item.symbol || key} paper units at ₹${fmt(response.order.price)}.`);
      await refreshPositions();
    } catch (e) {
      setOrderError(e.message);
    } finally {
      setOrderBusy("");
    }
  };

  const currentPositions = executionMode === "live" ? livePositions : positions;
  return (
    <section className="card">
      <h2>Options scanner</h2>
      <p className="note">
        Scanner recommendations are informational. In Paper mode, Buy opens one lot in the paper account.
        In Live mode, Buy submits a real one-lot Upstox order, and Sell is limited to closing an existing
        long broker position. Every live order requires confirmation and is subject to the backend order-value cap.
        The expiry defaults to the nearest listed NIFTY 50 expiry; pick a later date to scan that instead.
        It applies to every underlying in the scan, and any underlying without contracts on that date is
        listed under errors. Then it considers
        near-the-money calls and puts. Requires an Upstox login and live option-chain access.
        Options are high risk; premiums may fall to zero. This is not financial advice.
      </p>
      <div className="row">
        <label>Underlying universe
          <select value={universe} onChange={(event) => setUniverse(event.target.value)}>
            {UNIVERSES.map(([value, label]) => <option key={value} value={value}>{label}</option>)}
          </select>
        </label>
        <label>Expiry
          <select value={expiry} onChange={(event) => setExpiry(event.target.value)} disabled={!expiries.length}>
            {!expiries.length && <option value="">Loading expiries…</option>}
            {expiries.map((value) => <option key={value} value={value}>{value}</option>)}
          </select>
        </label>
        <label>Show top recommendations
          <select value={limit} onChange={(event) => setLimit(Number(event.target.value))}>
            {[10, 20, 50].map((value) => <option key={value} value={value}>{value}</option>)}
          </select>
        </label>
        <button className="primary" disabled={busy} onClick={scan}>
          {busy ? "Refreshing…" : "Refresh options"}
        </button>
        <button onClick={() => setAutoRefresh((enabled) => !enabled)}>
          {autoRefresh ? "Pause 1-minute refresh" : "Resume 1-minute refresh"}
        </button>
        <span className="badge">{autoRefresh ? "Auto-refresh ON · 1 min" : "Auto-refresh OFF"}</span>
      </div>
      {lastUpdated && <p className="note">Last refreshed: {lastUpdated.toLocaleTimeString()}</p>}
      {error && <div className="err" role="alert">{error}</div>}
      {result && (
        <>
          <p className="note">
            Scanned {result.scanned} underlyings; {result.recommendations.length} passed all
            filters. Recommendations refresh every minute while this tab is open. The default
            universe is NIFTY 50 and BANK NIFTY indexes; a full stock scan makes many broker requests.
          </p>
          {result.recommendations.length === 0 ? (
            <p className="note">No option passed the model-agreement, validation, and liquidity checks.</p>
          ) : (
            <div className="table-scroll">
              <table>
                <thead>
                  <tr>
                    <th>Underlying</th><th>Idea</th><th>Option contract</th><th>Expiry</th>
                    <th>Spot</th><th>Strike</th><th>Premium</th><th>Bid / ask</th>
                    <th>Spread %</th><th>Delta</th><th>RF P(up)</th><th>XGB P(up)</th>
                    <th>Volume</th><th>OI</th><th>Rank</th><th>{executionMode === "live" ? "Live order" : "Paper order"}</th>
                  </tr>
                </thead>
                <tbody>
                  {result.recommendations.map((item) => (
                    <tr key={item.instrument_key}>
                      <td>{item.underlying}</td>
                      <td className={item.direction === "CALL" ? "up" : "dn"}>{item.direction}</td>
                      <td>{item.trading_symbol || item.instrument_key}</td>
                      <td>{item.expiry}</td>
                      <td>{fmt(item.spot)}</td>
                      <td>{fmt(item.strike)}</td>
                      <td>{fmt(item.premium)}</td>
                      <td>{fmt(item.bid)} / {fmt(item.ask)}</td>
                      <td>{fmt(item.spread_pct)}%</td>
                      <td>{fmt(item.delta, 3)}</td>
                      <td>{fmt(item.random_forest_probability_up * 100)}%</td>
                      <td>{fmt(item.xgboost_probability_up * 100)}%</td>
                      <td>{Number(item.volume).toLocaleString("en-IN")}</td>
                      <td>{Number(item.open_interest).toLocaleString("en-IN")}</td>
                      <td>{fmt(item.ranking_score)}</td>
                      <td>
                        {currentPositions.some((position) => position.key === item.instrument_key) ? (
                          <button
                            className="primary sell"
                            disabled={Boolean(orderBusy)}
                            onClick={() => placeOptionOrder(item, "SELL")}
                          >
                            {orderBusy === item.instrument_key ? "Working…" : "Sell to close"}
                          </button>
                        ) : (
                          <button
                            className="primary buy"
                            disabled={Boolean(orderBusy)}
                            onClick={() => placeOptionOrder(item, "BUY")}
                          >
                            {orderBusy === item.instrument_key ? "Working…" : "Buy 1 lot"}
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          {result.no_trade.length > 0 && (
            <details className="scan-errors">
              <summary>{result.no_trade.length} underlyings had no trade signal</summary>
              <ul>
                {result.no_trade.map((item) => (
                  <li key={item.underlying}>{item.underlying}: {item.reason}</li>
                ))}
              </ul>
            </details>
          )}
          {Object.keys(result.errors).length > 0 && (
            <details className="scan-errors">
              <summary>{Object.keys(result.errors).length} underlyings were skipped</summary>
              <ul>
                {Object.entries(result.errors).map(([name, message]) => (
                  <li key={name}>{name}: {message}</li>
                ))}
              </ul>
            </details>
          )}
          <p className="note">{result.method}</p>
        </>
      )}
      <section className="card">
        <h3>{executionMode === "live" ? "Live broker option positions" : "Manual paper option positions"}</h3>
        <p className="note">
          {executionMode === "live"
            ? "Only long NSE option positions returned by Upstox are shown. Sell submits a close-only order for the full broker-reported quantity; short option positions cannot be opened here."
            : "Buy opens one lot, subject to the 2% paper-equity premium cap and contract checks. Sell closes the full existing option position only; option short-selling is disabled."}
        </p>
        {orderMessage && <div className="up" role="status">{orderMessage}</div>}
        {orderError && <div className="err" role="alert">{orderError}</div>}
        {currentPositions.length === 0 ? (
          <p className="note">No open NSE option {executionMode === "live" ? "broker" : "paper"} positions.</p>
        ) : (
          <div className="table-scroll">
            <table>
              <thead><tr><th>Contract</th><th>Key</th><th>Quantity</th><th>Average premium</th><th>Action</th></tr></thead>
              <tbody>
                {currentPositions.map((position) => (
                  <tr key={position.key}>
                    <td>{position.symbol}</td><td>{position.key}</td><td>{position.qty}</td>
                    <td>{fmt(position.avg_price)}</td>
                    <td>
                      <button
                        className="primary sell"
                        disabled={Boolean(orderBusy)}
                        onClick={() => placeOptionOrder(position, "SELL")}
                      >
                        {orderBusy === position.key ? "Working…" : "Sell to close"}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
      <section className="card">
        <h3>Automatic options paper trading</h3>
        <p className="note">
          Simulated orders only—no live orders are sent. The bot checks every 60 minutes during
          market hours, buys at most one lot per underlying, limits premium cost to 2% of paper
          equity per position, and holds at most 3 positions. It exits at a 30% premium loss, 50%
          premium gain, or at least one weekday before expiry. Stops are polled; prices can move
          through them between checks. Review the latest status and paper account before enabling.
        </p>
        <div className="row">
          <label>Auto-trade universe
            <select value={autoUniverse} onChange={(event) => setAutoUniverse(event.target.value)}>
              {UNIVERSES.map(([value, label]) => <option key={value} value={value}>{label}</option>)}
            </select>
          </label>
          <button className="primary" disabled={autoBusy} onClick={runPaperCycle}>
            {autoBusy ? "Working…" : "Run one paper cycle"}
          </button>
          <button
            className={autoStatus?.running ? "sell" : "primary"}
            disabled={autoBusy}
            onClick={toggleAuto}
          >
            {autoBusy ? "Working…" : autoStatus?.running ? "Stop auto paper" : "Start auto paper"}
          </button>
          <span className="badge">{autoStatus?.running ? "Auto paper ON" : "Auto paper OFF"}</span>
          {autoStatus?.last_result && (
            <span className="badge">Open option positions: {autoStatus.last_result.open_positions}</span>
          )}
        </div>
        {autoError && <div className="err" role="alert">{autoError}</div>}
        {autoStatus?.last_error && <div className="err" role="alert">Last cycle: {autoStatus.last_error}</div>}
        {autoStatus?.positions?.length > 0 && (
          <div className="scan-errors">
            <strong>Auto-managed positions</strong>
            <ul>
              {autoStatus.positions.map((position) => (
                <li key={position.key}>
                  {position.symbol}: {position.qty} contracts; entry {fmt(position.avg_price)},
                  {" "}stop {fmt(position.stop_loss)}, target {fmt(position.take_profit)},
                  {" "}expiry {position.expiry}
                </li>
              ))}
            </ul>
          </div>
        )}
        {autoResult && (
          <div className="scan-errors" role="status">
            Cycle complete: {autoResult.scanned} underlyings scanned; {autoResult.open_positions}
            {" "}auto-managed option positions open.
            {autoResult.actions.length > 0 && (
              <ul>
                {autoResult.actions.map((action, index) => (
                  <li key={`${action.underlying}-${action.action}-${index}`}>
                    {action.action} {action.symbol || action.underlying}: {action.reason}
                  </li>
                ))}
              </ul>
            )}
            {Object.keys(autoResult.errors).length > 0 && (
              <ul>
                {Object.entries(autoResult.errors).map(([name, message]) => (
                  <li key={name}>{name}: {message}</li>
                ))}
              </ul>
            )}
          </div>
        )}
      </section>
    </section>
  );
}
