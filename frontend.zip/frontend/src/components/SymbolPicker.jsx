import React, { useId } from "react";

export default function SymbolPicker({ label = "Symbol", symbol, instruments, onChange }) {
  const listId = useId();
  return (
    <label>
      {label}
      <input
        list={listId}
        value={symbol}
        onChange={(event) => onChange(event.target.value.toUpperCase())}
        autoComplete="off"
        spellCheck="false"
      />
      <datalist id={listId}>
        {Object.keys(instruments).map((name) => <option key={name} value={name} />)}
      </datalist>
    </label>
  );
}
